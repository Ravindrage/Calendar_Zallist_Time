TimeScheduler
=============

A simple JavaScript Timeline Scheduler library

[Go here for a live demo using the latest version](http://zallist.github.io/TimeScheduler/Calendar.html)

License
=
The library is made available under the MIT license. 
http://en.m.wikipedia.org/wiki/MIT_License
