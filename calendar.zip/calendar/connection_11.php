<?php

ini_set('display_errors', 1);

$servername = "localhost" ;
$username   = "root" ;
$password   = "" ;
$dbname     = "calendar" ;


// Create connection
global $conn;
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conect = mysqli_connect("localhost","root","", "calendar") or die(mysql_error());

?>
