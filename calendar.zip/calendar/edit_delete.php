<?php

include("connection.php");
global $conn;

//print_r ($_REQUEST);

//print_r($_REQUEST);



if(isset($_REQUEST['action']) and ($_REQUEST['action']=="edit"))
{
  //sqlcategory = "Update from calendar order by datetime";
  $event = trim($_REQUEST['eventdata']);
  $description = trim($_REQUEST['eventdesc']);
  $id = trim($_REQUEST['dataid']);
  $starttime = $_REQUEST['starttime'] ;
  $endtime =  $_REQUEST['endtime'] ;
  $status =  $_REQUEST['status'] ;

  $sqlcategory = "UPDATE calendar SET event='".$event."' , description ='".$description."' , starttime='".$starttime."', endtime='".$endtime."' ,status='".$status."' WHERE id = '".$id."'";
  $calendarcategory = $conn->query($sqlcategory);

  $sqlcategory = "select * from calendar  WHERE id = '".$id."'";
  $calendarcategory = $conn->query($sqlcategory);

  foreach($calendarcategory as $rowcategory)
  {

  $datetime = $rowcategory['datetime'] ;
  $event = $rowcategory['event'] ;
  $description = $rowcategory['description'] ;
  $section = $rowcategory['section'] ;
  $starttime = $rowcategory['starttime'] ;
  $endtime = $rowcategory['endtime'] ;
  $status = $rowcategory['status'] ;

  $newDate = date("m-d-Y", strtotime($datetime));

  }

  echo '<div class="time-sch-item-content"><div>
  <div>'.$event.'</div>
  <div>'.$description.'</div>
  </div></div>
  <div class="time-sch-item-start"></div>
  <div class="time-sch-item-end"></div>
  <div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div>
  <div class="ui-resizable-handle ui-resizable-w" style="z-index: 90;"></div>';

}


if(isset($_REQUEST['action']) and ($_REQUEST['action']=="delete"))
{
  $dataid = $_REQUEST['dataid'] ;
  $id = trim($_REQUEST['dataid']);

  $sqlcategory = "delete from calendar where id=".$id;
  $calendarcategory = $conn->query($sqlcategory);
  echo "delete";

}


if(isset($_REQUEST['action']) and ($_REQUEST['action']=="save"))
{
  $event = trim($_REQUEST['eventdata']);
  $description = trim($_REQUEST['eventdesc']);
  $description ;
  $section = $_REQUEST['section'] ;
  $date = $_REQUEST['date'] ;
  $newDate = date("Y-m-d", strtotime($date));
  $starttime = $_REQUEST['starttime'] ;
  $endtime =  $_REQUEST['endtime'] ;

  $sqlcategory = "INSERT INTO calendar (`event`,`description`,`section`,`datetime`,`starttime`,`endtime` ) VALUES ('".$event."','".$description."','".$section."','".$newDate."','".$starttime."','".$endtime."')";
  $calendarcategory = $conn->query($sqlcategory);
  $last_id = mysqli_insert_id($conn);

  $sqlcategory = "select * from calendar where id= '".$last_id."' ";
  $calendarcategory = $conn->query($sqlcategory);
  $variable = '';
  $i=0;
  foreach($calendarcategory as $rowcategory)
  {
    $datetime = $rowcategory['datetime'] ;
    $event = $rowcategory['event'] ;
    $description = $rowcategory['description'] ;

    $newDate = date("m-d-Y", strtotime($datetime));

    echo $last_id.'$<div class="time-sch-item-content"><div>
    <div>'.$event.'</div>
    <div>'.$description.'</div>
    </div></div>
    <div class="time-sch-item-start"></div>
    <div class="time-sch-item-end"></div>
    <div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div>
    <div class="ui-resizable-handle ui-resizable-w" style="z-index: 90;"></div>';


  }
//  echo json_encode($variableArray);
  //echo $variable;

}


if(isset($_REQUEST['action']) and ($_REQUEST['action']=="editsection"))
{
  $sectionid = $_REQUEST['sectionid'] ;
  $sectionname = trim($_REQUEST['sectionname']);

  $sqlcategory = "UPDATE section SET section ='".$sectionname."' WHERE id = '".$sectionid."'";
  $calendarcategory = $conn->query($sqlcategory);

  $sqlcategory = "select * from section  WHERE id = '".$sectionid."'";
  $calendarcategory = $conn->query($sqlcategory);

  foreach($calendarcategory as $rowcategory)
  {   echo $sectionname = $rowcategory['section'] ;  }

}


if(isset($_REQUEST['action']) and ($_REQUEST['action']=="showdata"))
{
  $date = $_REQUEST['date'] ;
//  $sectionname = trim($_REQUEST['sectionname']);

  $sqlcategory = "select * from calendar  WHERE datetime = '".$date."' order by starttime ";
  $calendarcategory = $conn->query($sqlcategory);
  $row = '<tr><td>Sr.No.</td><td>Event Name</td> <td> Description</td> <td>Start Time</td> <td>End Time</td><td>Status</td></tr>';
 $i = 0;
if ($calendarcategory->num_rows > 0) {
  foreach($calendarcategory as $rowcategory)
    {  $i++ ;
    $event = $rowcategory['event'] ;
    $description = $rowcategory['description'];
    $datetime = $rowcategory['datetime'];
    $starttime = $rowcategory['starttime'];
    $endtime  = $rowcategory['endtime'];
    $status  = $rowcategory['status'];
    $row .= '<tr style="background-color:#888;"><td>'.$i.'</td><td>'.$event.'</td><td>'.$description.'</td><td>'.$starttime.':00</td><td>'.$endtime.':00</td><td>'.$status.'</td></tr>';
    }
  echo $table = '<div style="border=1;font-size:12px;"><table colspan="0" rowspan="0" >'.$row.'</table></div>';
  }

}




if(isset($_REQUEST['action']) and ($_REQUEST['action']=="showeditdata"))
{

  $dataid = $_REQUEST['dataid'] ;
  $sqlcategory = "select * from calendar  WHERE id = '".$dataid."'";
  $calendarcategory = $conn->query($sqlcategory);

  foreach($calendarcategory as $rowcategory)
  {
  $datetime = $rowcategory['datetime'] ;
  $event = $rowcategory['event'] ;
  $description = $rowcategory['description'] ;
  $section = $rowcategory['section'] ;
  $starttime = $rowcategory['starttime'] ;
  $endtime = $rowcategory['endtime'] ;
  $status = $rowcategory['status'] ;
  $newDate = date("m-d-Y", strtotime($datetime));
  }

  $arrayName = array('event' =>$event ,'datetime' =>$datetime,'description'=>$description,'starttime'=>$starttime,'endtime'=>$endtime,'status'=>$status);
  echo json_encode($arrayName);

}




?>
